<!--
 * @Descripttion:
 * @version:
 * @Author: wangjie
 * @Date: 2021-11-27 15:16:16
 * @LastEditors: wangjie
 * @LastEditTime: 2021-11-29 10:45:14
-->

#

> target：指定容器 默认 document
> 固定在容器内，容器不在窗口内则隐藏

> offset: 多少像素 px 默认 0
> position: top bottom 距上 距下 默认 top
