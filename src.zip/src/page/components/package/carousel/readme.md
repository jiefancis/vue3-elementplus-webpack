<!--
 * @Descripttion:
 * @version:
 * @Author: wangjie
 * @Date: 2021-11-30 15:43:26
 * @LastEditors: wangjie
 * @LastEditTime: 2021-11-30 15:53:35
-->

autoplay
trigger hover click
show-arrow
interval
