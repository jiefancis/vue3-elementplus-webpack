/*
 * @Descripttion:
 * @version:
 * @Author: wangjie
 * @Date: 2021-09-13 17:17:11
 * @LastEditors: wangjie
 * @LastEditTime: 2021-10-08 11:24:47
 */
export default {
  search: {
    user: '用户'
  }
}
