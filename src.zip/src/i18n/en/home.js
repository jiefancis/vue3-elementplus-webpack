/*
 * @Descripttion:
 * @version:
 * @Author: wangjie
 * @Date: 2021-09-13 19:48:23
 * @LastEditors: wangjie
 * @LastEditTime: 2021-10-08 11:25:00
 */
export default {
  search: {
    user: 'user'
  }
}
