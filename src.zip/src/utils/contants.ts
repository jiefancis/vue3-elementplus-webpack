/*
 * @Descripttion:
 * @version:
 * @Author: wangjie
 * @Date: 2021-10-08 15:19:45
 * @LastEditors: wangjie
 * @LastEditTime: 2021-10-08 15:21:23
 */
export const SEARCH = [
  { id: 1, name: '1' },
  { id: 2, name: '2' },
  { id: 3, name: '3' },
  { id: 4, name: '4' },
  { id: 1, name: '1' },
  { id: 2, name: '2' },
  { id: 3, name: '3' },
  { id: 4, name: '4' }
]
