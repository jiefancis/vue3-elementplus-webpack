/*
 * @Descripttion:
 * @version:
 * @Author: wangjie
 * @Date: 2021-09-13 18:05:37
 * @LastEditors: wangjie
 * @LastEditTime: 2021-09-13 19:48:29
 */
import home from './home';
export default {
  home
}
