/*
 * @Descripttion:
 * @version:
 * @Author: wangjie
 * @Date: 2021-09-13 18:05:43
 * @LastEditors: wangjie
 * @LastEditTime: 2021-10-08 11:24:49
 */

import home from './home'
export default {
  home
}
