/*
 * @Descripttion:
 * @version:
 * @Author: wangjie
 * @Date: 2021-09-09 14:11:15
 * @LastEditors: wangjie
 * @LastEditTime: 2021-10-08 15:57:19
 */
import { createStore } from 'vuex'
import home from './home'

export default createStore({
  modules: {
    home
  }
})
