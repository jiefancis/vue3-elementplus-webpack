<!--
 * @Descripttion:
 * @version:
 * @Author: wangjie
 * @Date: 2021-11-09 16:57:58
 * @LastEditors: wangjie
 * @LastEditTime: 2021-11-09 17:05:25
-->
<template>
  <div class="transfer-window">
    <div class="transfer-header">
      <input type="check" v-model="allChecked"/>
      <!-- < -->
    </div>
  </div>
</template>
<script lang="ts">
import { defineComponent } from 'vue'
export default defineComponent({
  setup(){

  }
})
</script>