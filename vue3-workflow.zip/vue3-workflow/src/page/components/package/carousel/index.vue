<!--
 * @Descripttion:
 * @version:
 * @Author: wangjie
 * @Date: 2021-11-30 15:43:13
 * @LastEditors: wangjie
 * @LastEditTime: 2021-11-30 18:54:18
-->
<template>
 <div class="m-carousel--wrap">
  <div class="m-carousel">
    <transition-group name="carousel">
      <div class="m-carousel--container" :style="{transform: `translate(${active * parseFloat(width)}, 0)`}">

          <slot></slot>
      </div>
    </transition-group>
    <div class="m-carousel--indicator">
      <div
        :class="['indicator-line', active === index ? 'active ' : '']"
        v-for="index in carouselNumber"
        :key="index"
        @mouseenter="() => indicatorEvent(index)"
        v-show="isHoverTrigger"></div>
      <div
        :class="['indicator-line', active === index ? 'active ' : '']"
        v-for="index in carouselNumber"
        :key="index"
        @click="() => indicatorEvent(index)"
        v-show="!isHoverTrigger"></div>
    </div>
    <div class="m-carousel--arrow arrow-left">&lt;</div>
    <div class="m-carousel--arrow arrow-right">&gt;</div>
  </div>
 </div>
</template>
<script lang='ts'>
import { defineComponent, ref, computed } from 'vue'

export default defineComponent({
 name: 'mCarousel',
 props: {
  autoplay: {
    type: Boolean,
    default: true
  }, // 自动切换
  // 自动切换时间间隔 （s）
  intervalTime: {
    type: Number,
    default: 500
  },
  // 是否显示箭头
  showArrow: {
    type: Boolean,

    default: false
  },
  // 触发方式
  trigger: {
    type: String,
    default: 'hover'
  },
  width: {
    type: String,
    default: '100%'
  },
  height: {
    type: String,
    default: '300px'
  }

 },
 setup(props, ctx) {
  const carouselNumber = ref<number>(ctx.slots?.default?.()?.length || 0)
  const isHoverTrigger = computed<boolean>(() => props.trigger === 'hover')
  const active = ref<number>(-1)
  const translateStyle = ref<any>()
  console.log(props, 'slots',ctx.slots?.default?.())

  function indicatorEvent(i: number) {
    active.value = i
    console.log("i * Number(props.width)", i * parseFloat(props.width), i, parseFloat(props.width))
    translateStyle.value = `translate(${i * parseFloat(props.width)},0)`
    console.log('translateStyle')
  }
   return {
    ...props,
    carouselNumber,
    isHoverTrigger,
    indicatorEvent,
    translateStyle,
    active
   }
 }

})

</script>

<style lang='scss' scoped>
// 过渡
.carousel-enter-active,
.carousel-leave-active{
  transition: all 0.5s ease;
}

.carousel-enter-from,
.carousel-leave-to{
  transform: translate(0,0)
}

.m-carousel--wrap{
  position: relative;
  width: v-bind(width);
  height: v-bind(height);
  overflow: hidden;
}
.m-carousel{
  display: inline-block;
  white-space: nowrap;
}
.m-carousel--indicator{
  position: absolute;
  left: 0;
  right: 0;
  bottom: 20px;
  text-align: center;
  .indicator-line{
    display: inline-block;
    height: 2px;
    width: 10px;
    background: #f0f0f0;
    margin: 0 5px 0 0;
  }
  .active{
    background: #ccc;
  }
}
.m-carousel--arrow{
  position: absolute;
  top: 50%;
  transform: translate(0, -50%);
  width: 30px;
  height: 50px;
  line-height: 50px;
  text-align: center;
  background: #fff;
}
.arrow-left{
    left: 0
  }
  .arrow-right{
    right: 0;
  }
</style>
