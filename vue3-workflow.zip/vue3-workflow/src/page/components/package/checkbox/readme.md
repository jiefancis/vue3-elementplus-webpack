<!--
 * @Descripttion:
 * @version:
 * @Author: wangjie
 * @Date: 2021-11-09 17:25:19
 * @LastEditors: wangjie
 * @LastEditTime: 2021-11-10 13:40:55
-->

# usage

1. basic

```
<m-checkbox v-model:checked="checked">
```

2. group

```
<m-checkbox-group>
  <m-checkbox value="1" label="tag"/>
</m-checkbox-group>
```

# ouput

checked boolean

# group how to get group-item value
