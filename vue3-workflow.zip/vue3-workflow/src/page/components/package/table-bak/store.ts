/*
 * @Descripttion:
 * @version:
 * @Author: wangjie
 * @Date: 2021-11-09 15:16:39
 * @LastEditors: wangjie
 * @LastEditTime: 2021-11-10 09:00:52
 */
const mapState = function(){

}

function createStore(){}