/*
 * @Descripttion:
 * @version:
 * @Author: wangjie
 * @Date: 2021-11-09 14:28:03
 * @LastEditors: wangjie
 * @LastEditTime: 2021-11-09 14:30:25
 */

import table from './index.vue'
import tableColumn from './m-table-column.vue'
export const mTable = table
export const mTableColumn = tableColumn