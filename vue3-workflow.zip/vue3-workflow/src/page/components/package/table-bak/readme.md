<!--
 * @Descripttion:
 * @version:
 * @Author: wangjie
 * @Date: 2021-11-09 11:38:25
 * @LastEditors: wangjie
 * @LastEditTime: 2021-11-09 15:04:03
-->

# usage

1. element

```
   <el-table :data="data">
    <el-table-column prop="name" label="用户名"/>
    <el-table-column prop="account" label="账号"/>
    <el-table-column prop="pwd" label="密码"/>
   </el-table>
```

2. naive-ui
   <n-data-table :columns="columns" :data="data" :pagination="pagination">

# vue3

1. setup synax slots get?
