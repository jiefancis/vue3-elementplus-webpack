<!--
 * @Descripttion:
 * @version:
 * @Author: wangjie
 * @Date: 2021-10-28 20:10:06
 * @LastEditors: wangjie
 * @LastEditTime: 2021-10-29 17:33:58
-->
<template>
  <div>
    input
  </div>
</template>
<script lang="ts" setup>
import { ref } from 'vue'
let value = ref('input')
</script>