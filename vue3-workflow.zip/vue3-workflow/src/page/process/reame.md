<!--
 * @Descripttion:
 * @version:
 * @Author: wangjie
 * @Date: 2021-11-15 11:17:28
 * @LastEditors: wangjie
 * @LastEditTime: 2021-11-15 11:17:29
-->

# action

1. 添加节点：
   addFLowNode
   addBranchNode
   分支节点中添加分支
   addBranch

2. 删除节点
   delNode
   delBranch 删除分支
