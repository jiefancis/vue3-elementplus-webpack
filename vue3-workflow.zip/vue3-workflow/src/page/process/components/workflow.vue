<!--
 * @Descripttion:
 * @version:
 * @Author: wangjie
 * @Date: 2021-11-16 22:38:42
 * @LastEditors: wangjie
 * @LastEditTime: 2021-11-16 22:58:57
-->
<template>
  <div>
    <div></div>
  </div>
</template>
<script lang="ts">
import { defineComponent, ref } from "vue"
export default defineComponent({
  setup() {
    const nodes = ref<Record<string, any>>({})

    function createBranch() {

    }

    /**
     * nodes = {
     *  type: 'normal',
     *  name: '',
     *  childNode: {
     *
     *  }
     * }
     */
  }
})
</script>
