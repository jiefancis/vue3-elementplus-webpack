<!--
 * @Descripttion:
 * @version:
 * @Author: wangjie
 * @Date: 2021-09-17 17:04:49
 * @LastEditors: wangjie
 * @LastEditTime: 2021-10-08 15:55:28
-->
<template>
  <div>404页面</div>
</template>
<script lang="ts" setup>
</script>
