/*
 * @Descripttion:
 * @version:
 * @Author: wangjie
 * @Date: 2021-09-10 14:29:54
 * @LastEditors: wangjie
 * @LastEditTime: 2021-09-18 14:48:12
 */
module.exports = {
  presets: ['@vue/cli-plugin-babel/preset']
  // plugins: [
  //   "@vue/bable-plugin-jsx"
  // ]
}
